/**
 * Created by zj on 2016/11/6.
 */

angular.module('starter.services',[]);